# conkies
Conky files for manjaro
